Heyo! Thanks for downloading the Sprout Lands UI asset pack. 
-Made by: Cup Nooble 

This asset pack is the start of a series of different asset packs, 
so let me know if there's any specific sprites you'd like in future packs.

License - Premium Pack
 - You can modify the assets.
 - You can not redistribute or resale, even if modified.
 - You can use these assets in non-commercial and commercial projects. [ But No NFT's pls ]
( Please credit me : (Cup Nooble) )

Follow Sprout Lands on Twitter for future updates :
https://twitter.com/Sprout_Lands

If you enjoy this asset pack consider leaving a rating and a comment. 
It really helps to support this project! :D
